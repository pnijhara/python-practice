from GymManager import GymManager
import pickle

try:
    gymManager = pickle.load(open("gym_data.pick", "rb"))
    print "Loaded data from gym_data.pick"
except:
    print "Existing data not found. Created new gym data."
    gymManager = GymManager()
print "Hello Admin, please select a choice from the menu"

def menu():
    print "1. Add customer"
    print "2. Show all customers"
    print "3. Find customer by name"
    print "4. Add payment"
    print "5. Show this menu again"
    print "6. Exit"

menu()

while True:
    input = int(raw_input())
    if input == 1:
        customer = dict()
        customer["name"] = str(raw_input("Enter customer's name - "))
        customer["phone_no"] = str(raw_input("Enter customer's phone no. - "))
        customer["join_month"] = str(raw_input("Enter joining month - "))
        customer["last_payed_for"] = None
        gymManager.addCustomer(customer)
        print "Customer added."

    elif input == 2:
        gymManager.showAllCustomers()

    elif input == 3:
        name = str(raw_input("Enter customer's name - "))
        customer = gymManager.findCustomerByName(name)
        if customer is None:
            print "Customer with name", name, "not found"
        else:
            print "Customer found - ", customer[0]

    elif input == 4:
        name = str(raw_input("Enter customer name - "))
        month = str(raw_input("Paying for which month? - "))
        output = gymManager.addPayment(name, month)
        if not output:
            print "Customer with name", name, "not found."
        else:
            print "Payment added."

    elif input == 5:
        menu()
        continue

    elif input == 6:
        gymManager.save()
        print "bye"
        exit(0)

    menu()
