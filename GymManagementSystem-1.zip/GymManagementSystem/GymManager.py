import pickle


class GymManager:
    def __init__(self):
        self.customers = list()

    def addCustomer(self, customer):
        self.customers.append(customer)

    def addPayment(self, name, month):
        found = False
        i = 0
        for customer in self.customers:
            i += 1
            if customer["name"].lower() == name.lower():
                found = True
                customer["last_payed_for"] = month
                break
        return found

    def findCustomerByName(self, name):
        found = None
        i = 0
        for customer in self.customers:
            i += 1
            if customer["name"].lower() == name.lower():
                found = customer
                break
        return (found, i)

    def showAllCustomers(self):
        for customer in self.customers:
            print customer

    def save(self):
        pickle.dump(self, open("gym_data.pick", "wb"))
